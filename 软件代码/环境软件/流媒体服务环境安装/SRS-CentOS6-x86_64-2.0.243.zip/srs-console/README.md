The management console for srs.
